package com.cg.banking.services;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.*;

public class BankingServicesImpl implements BankingServices{
	private BankingDAOServices daoservices;
	public BankingServicesImpl() {
		daoservices = new BankingDAOServicesImpl();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
	

		return daoservices.insertCustomer(new Customer(firstName, lastName, customerEmailId,panCard, new Address(localAddressCity,localAddressState, localAddressPinCode),new Address(homeAddressCity,homeAddressState,homeAddressPinCode)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) {
		
		return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {
		float totalbal=daoservices.getAccount(customerId, accountNo).getAccountBalance()+amount;
		daoservices.getAccount(customerId, accountNo).setAccountBalance(totalbal);
		daoservices.insertTransaction(customerId, accountNo, new Transaction(amount, "deposit"));
		return daoservices.getAccount(customerId, accountNo).getAccountBalance();
	
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {	
		float finalamt=daoservices.getAccount(customerId, accountNo).getAccountBalance()-amount;
		if(daoservices.getAccount(customerId, accountNo).getPinNumber()==pinNumber) {
		daoservices.getAccount(customerId, accountNo).setAccountBalance(finalamt);
		daoservices.insertTransaction(customerId, accountNo, new Transaction(amount,"withdraw"));
		return daoservices.getAccount(customerId, accountNo).getAccountBalance();
	}
	return -1;
}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
	float x=withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
	if(x!=-1) {
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) {
		
		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {
	
		return daoservices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
	
		return daoservices.generatePin(customerId, getAccountDetails(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {

		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() {
		
		return daoservices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {
		
		return daoservices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {

		return daoservices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {
	
		return daoservices.getAccount(customerId, accountNo).getStatus();
	}
	
	

}
