package com.cg.banking.daoservices;
import com.cg.banking.beans.*;
import com.cg.banking.services.*;
import java.util.Random;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;


public class BankingDAOServicesImpl implements BankingDAOServices{
	Random rand = new Random();
	private static Customer[] customerList=new Customer[100];
	private static int CUSTOMER_ID_COUNTER=10;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int ACCCOUNT_ID_COUNTER = 1234;
	private static int TRANSACTION_ID_COUNTER=1111;
	 public int insertCustomer(Customer customer) {
		 if(CUSTOMER_IDX_COUNTER > 0.7*(customerList.length)) {
			 Customer[] tempList =new Customer[customerList.length+10];
			 System.arraycopy(customerList,0,tempList,0,customerList.length);
				customerList=tempList;
		 }
		 customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		 customerList[CUSTOMER_IDX_COUNTER++] = customer;
		 return customer.getCustomerId();
	}
	public long insertAccount(int customerId, Account account) {
		if(getCustomer(customerId).getAccountIDXCounter()>0.7*(getAccounts(customerId).length)) {
			Account[] acctList = new Account[getAccounts(customerId).length+5];
			System.arraycopy(getAccounts(customerId),0, acctList,0, getAccounts(customerId).length);
			getCustomer(customerId).setAccounts(acctList);
		}
		account.setAccountNo(ACCCOUNT_ID_COUNTER++);
		getAccounts(customerId)[getCustomer(customerId).getAccountIDXCounter()]=account;
		getCustomer(customerId).setAccountIDXCounter(getCustomer(customerId).getAccountIDXCounter()+1);
		return account.getAccountNo();
	}


	public boolean updateAccount(int customerId, Account account) {
		for(int j=0;j<getCustomer(customerId).getAccounts().length;j++) {
		if(getCustomer(customerId).getAccounts()!=null && getCustomer(customerId).getAccounts()[j].getAccountNo()==account.getAccountNo());
		
		getCustomer(customerId).getAccounts()[j]=account;
		return true;
	}
		return false;
}



	@Override
	public int generatePin(int customerId, Account account) {
		long accountNo = account.getAccountNo();
		getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9000)+1000);
		return getAccount(customerId, accountNo).getPinNumber();
	}

	
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo).getTransactionIDXCounter()>0.7*getTransactions(customerId, accountNo).length) {
			 Transaction[] temp = new Transaction[getTransactions(customerId, accountNo).length+10];
			System.arraycopy(getTransactions(customerId, accountNo), 0, temp, 0, getTransactions(customerId, accountNo).length);
		return true;
		}
		return false;
	}
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<=customerList.length;i++) 
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				return true;
			}
		return false;
	}
	

	
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId())
				for(int j=0;j<customerList[i].getAccounts().length;j++) {
					if(customerList[i].getAccounts()[j]!=null && customerList[i].getAccounts()[j].getAccountNo()==accountNo)
						customerList[i].getAccounts()[j]=null;
							return true;				
		}		
		return false;
	}

	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++) 
			if(customerId==customerList[i].getCustomerId())
				return customerList[i];
     return null;
	}


	public Account getAccount(int customerId, long accountNo) {
		for(int j=0;j<getCustomer(customerId).getAccounts().length;j++)
			if(getCustomer(customerId).getAccounts()[j].getAccountNo()==accountNo)
				return getCustomer(customerId).getAccounts()[j];
		return null;
	}

	
	public Customer[] getCustomers() {
		return customerList;
	}

	
	public Account[] getAccounts(int customerId) {
		return getCustomer(customerId).getAccounts();
	}

	
	public Transaction[] getTransactions(int customerId, long accountNo) {
		
		return getAccount(customerId, accountNo).getTransaction();
	}

	public int hashCode() {
		
		return super.hashCode();
	}

	
	public boolean equals(Object obj) {
	
		return super.equals(obj);
	}

	
	protected Object clone() throws CloneNotSupportedException {
		
		return super.clone();
	}


	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
	

}
