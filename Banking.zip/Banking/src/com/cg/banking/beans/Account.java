package com.cg.banking.beans;
public class Account {
	private int accountNo,pinNumber,pinCounter;
	private float accountBalance;
	private String accountType,status; 
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private Transaction[] transaction;
	private int TransactionIDXCounter=0;
	public Account(){}
	public Account(int accountNo, float accountBalance, String accountType, Transaction[] transaction,
			int transactionIDXCounter) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transaction = transaction;
		TransactionIDXCounter = transactionIDXCounter;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Account(  String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}
	public int getTransactionIDXCounter() {
		return TransactionIDXCounter;
	}
	public void setTransactionIDXCounter(int transactionIDXCounter) {
		TransactionIDXCounter = transactionIDXCounter;
	}
}