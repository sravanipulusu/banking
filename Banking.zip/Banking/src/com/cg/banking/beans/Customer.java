package com.cg.banking.beans;

import java.util.Arrays;

public class Customer {
	private int customerId,mobileNo,adharNo,pancardNo,dateOfBirth;
	private String firstName,lastName,emailId;
	private Account[] accounts;
	private int accountIDXCounter=0;
	private Address localAddress,homeAddress;
	public Customer(){}
	public Customer(int customerId, int mobileNo, int adharNo, int pancardNo, int dateOfBirth, String firstName,
			String lastName, String emailId, Account[] accounts, int accountIDXCounter, Address localAddress,
			Address homeAddress) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.accounts = accounts;
		this.accountIDXCounter = accountIDXCounter;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	public Customer(String firstName, String lastName, String customerEmailId, String panCard, Address localAddress,
			Address homeAddress)
	 {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancardNo = pancardNo;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
		

	
	public Customer(int customerId, int mobileNo, int adharNo, int pancardNo, String firstName,
			String lastName, String emailId, Address localAddress, Address homeAddress) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public int getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(int pancardNo) {
		this.pancardNo = pancardNo;
	}
	public int getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Account[] getAccounts() {
		return accounts;
	}
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	public int getAccountIDXCounter() {
		return accountIDXCounter;
	}
	public void setAccountIDXCounter(int accountIDXCounter) {
		this.accountIDXCounter = accountIDXCounter;
	}
	public Address getLocalAddress() {
		return localAddress;
	}
	public void setLocalAddress(Address localAddress) {
		this.localAddress = localAddress;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
}