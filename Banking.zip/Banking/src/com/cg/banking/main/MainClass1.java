package com.cg.banking.main;
import java.util.Scanner;

import com.cg.banking.beans.*;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass1 {
	public static void main(String[] args) {
		BankingServicesImpl bankservices=new BankingServicesImpl();
		Scanner a=new Scanner(System.in);
		int k=0;
		while (k!=11) {
			System.out.println("Select  Input\n"+"1)Register Customer\n2)Add Account\n3)Generate Pin\n4)Change Pin\n"
					+"5)Deposit Amount\n6)Withdraw Amount\n7)Fund Transfer\n8)Close Account\n"
					+"9)Remove Customer\n10)Get customer Details\n11)Exit Portal");
			k=a.nextInt();
			switch (k) {
			case 1:System.out.println("Enter customer Details in below order");
			System.out.println("Enter firstName");
			String firstName=a.next();
			System.out.println("Enter lastName");
			String lastName=a.next();
			System.out.println("Enter emailId");
			String emailId=a.next();
			System.out.println("Enter pancardNo");
			String panCard=a.next();
			System.out.println("Enter local Address city");
			String localAddressCity=a.next();
			System.out.println("Enter local Address state");
			String localAddressState=a.next();
			System.out.println("Enter local Pincode");
			int localAddressPinCode=a.nextInt();
			System.out.println("Enter home Address city");
			String homeAddressCity=a.next();
			System.out.println("Enter home Address state");
			String homeAddressState=a.next();
			System.out.println("Enter home Address Pincode");
			int homeAddressPinCode=a.nextInt();
			int cust=bankservices.acceptCustomerDetails(firstName,lastName,emailId,panCard,localAddressCity,localAddressState,localAddressPinCode,homeAddressCity,homeAddressState,homeAddressPinCode);
			System.out.println("Succesfully created customer with Id \n"+cust);
			System.out.println((bankservices.getCustomerDetails(cust)).toString());
			break;
			case 2:System.out.println("Enter account Details in below order\n");
			System.out.println("Enter Customer id");
			int cus=a.nextInt();
			System.out.println("Enter Account type");
			String acc=a.next();
			System.out.println("Enter Amount deposited");
			float deposit=a.nextFloat();
			long acc1=bankservices.openAccount(cus,acc,deposit);
			System.out.println("successfully added account "+acc1+" for customer of id "+cus+"\n");
			break;
			case 3:System.out.println("Enter the details");
			System.out.println("Enter CustomerId");
			int cus1=a.nextInt();
			System.out.println("EnterAccountNo");
			long acc2=a.nextLong();
			int pin=bankservices.generateNewPin(cus1,acc2);
			System.out.println("The generated Pin is"+pin);
			break;
			case 4:System.out.println("Enter the details for pin change\n"+"customerId, AccountNo,OldPin,NewPin");
			boolean flag=bankservices.changeAccountPin(a.nextInt(), a.nextLong(), a.nextInt(), a.nextInt());
			if(flag==true)
				System.out.println("Successfully pin changed");
			else
				System.out.println("Pin change failed give vaild details");
			break;
			case 5:System.out.println("enter the required details to deposit amount\n"+" CustomerId, AccountNo, Amount");
				float bal=bankservices.depositAmount(a.nextInt(), a.nextLong(),a.nextFloat());
				System.out.println("After Deposit the balance is "+bal);
				break;
			case 6:System.out.println("enter the required details to withdraw cash\n"+" CustomerId, AccountNo, Amount, Pin");
				float balan=bankservices.withdrawAmount(a.nextInt(),a.nextLong(), a.nextFloat(),a.nextInt());
				System.out.println("After Deposit the balance is "+balan);
				break;
			default:
				break;
			}
		}

		/*
		int cust=bankServices.acceptCustomerDetails("ravi", "teja", "email", "g55g6", "hyd", "Tg", 500072, "hyd", "Tg", 500072);
		System.out.println(cust);
		long acc=bankServices.openAccount(cust, "savings", 10000);
		//long acc1=bankServices.openAccount(cust, "savings", 300000);
		long acc2=bankServices.openAccount(cust, "savings",4300000);
		System.out.println(acc2);
		int pin=bankServices.generateNewPin(cust, acc);
		float bal=bankServices.depositAmount(cust, acc, 10000);
		float wit=bankServices.withdrawAmount(cust, acc, 15000,pin);
		boolean i=bankServices.changeAccountPin(cust, acc, pin, 1100);
		System.out.println((bankServices.getCustomerDetails(cust)).toString());
		System.out.println("pin"+" "+pin+" "+"Balance "+" "+bal+" "+"balance after withdrawl "+" "+wit+" "+i);*/
	}
		

}

